==============
 FluxLDAP
==============

This package manages LDAP Creation and LDAP Connection,
creating all base, new users and other things.


Jacson RC Silva <jacsonrcsilva@gmail.com>
